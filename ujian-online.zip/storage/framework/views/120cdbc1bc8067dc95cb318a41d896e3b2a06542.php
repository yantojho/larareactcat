<html>
<head>
  <title>Cetak Kartu Ujian</title>
  <style>
    @page  { 
      margin: 1cm; 
    }
    body { 
      margin: 0px; 
      font-size: 12px;
    }
    h4{
      font-size: 16px;
    }

    .kartu{
      border: 1px solid #000;
      margin-bottom: 20px;
    }
    .kartu td{
        padding: 0 5px;
    }

    .page-break {
      page-break-after: always;
    }
  </style>
</head>
<body>
   <table>
      <tr>
        <?php $no = 1 ?>
        <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td style="width: 9cm" valign="top">
          <table width="100%" class="kartu">
             <tr><td colspan="2" align="center"><h3>KARTU UJIAN</h3></td></tr>
             <tr><td>Nama</td><td>: <?php echo e($p->nama_peserta); ?></td></tr>
             <tr><td>Sekolah</td><td>: <?php echo e($p->nama_sekolah); ?></td></tr>
             <tr><td>Kelas</td><td>: <?php echo e($p->kelas); ?></td></tr>
             <tr><td>No. Ujian</td><td>: <?php echo e($p->no_ujian); ?></td></tr>
             <tr><td>Password</td><td>: <?php echo e($p->password); ?> <?php echo e($no); ?></td></tr>
          </table>
        </td>

        <?php if($no%2==0): ?>
            </tr><tr>
        <?php else: ?>
            <td style="width: 0.5cm"> &nbsp; </td>
        <?php endif; ?>

        <?php if($no%10==0): ?>
                </tr>
            </table>            
            <div class="page-break"></div>
            <table>
                <tr>
        <?php endif; ?>

        <?php $no++ ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
   </table>
</body>
</html><?php /**PATH D:\Source Code\ujian_react_laravel_bootstrap\resources\views/kartu_pdf.blade.php ENDPATH**/ ?>